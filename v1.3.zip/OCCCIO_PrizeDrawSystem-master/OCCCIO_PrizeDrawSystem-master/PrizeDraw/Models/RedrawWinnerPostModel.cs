﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrizeDraw.Models
{
    public class RedrawWinnerPostModel
    {
        public int? PrizeId { get; set; }

        public int? AttendeeId { get; set; }
    }
}
