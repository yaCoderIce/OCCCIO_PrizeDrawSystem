﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PrizeDraw.Models
{
    public class PrizeWinnerModel
    {
        public string Name { get; set; }

        public string OrganizationName { get; set; }

        public int AttendeeId { get; set; }
    }
}
