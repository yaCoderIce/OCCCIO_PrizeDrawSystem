﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PrizeDraw.Areas.Identity.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        /// <summary>
        /// Similar to _GET
        /// render during page request
        /// </summary>
        public void OnGet()
        {

        }


    }
}

